#!/bin/bash/
#
# This script supposed to insert new recodrs in .ssh/config file
#
#
