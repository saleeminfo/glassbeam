#!/bin/bash
echo `hostname` > test.txt
